<?php
include 'index.php'; // reuse $team and functions (or you could split into functions.php + data.php)

// figure out which member to show
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$member = $team[$id];

function displayWorkExperience($experience) {
    ?>
    <div class="work-item mb-3">
        <h4><?= e($experience['role']) ?> at <?= e($experience['company']) ?></h4>
        <p><em><?= e($experience['dates']) ?></em></p>
        <p><?= e($experience['desc']) ?></p>
    </div>
    <?php
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= e($member['name']) ?> — Profile</title>
    <meta charset="utf-8">
    <link href="assets/css/pillar-1.css" rel="stylesheet">
    <script defer src="assets/fontawesome/js/all.min.js"></script>
</head>
<body>
    <div class="container">
        <header class="my-4">
            <h1><?= e($member['name']) ?></h1>
            <p><?= e($member['title']) ?></p>
            <p>Age: <?= calculateAge($member['dob']) ?></p>
        </header>

        <section>
            <h2>Summary</h2>
            <p><?= e($member['summary']) ?></p>
        </section>

        <section>
            <h2>Work Experience</h2>
            <?php foreach ($member['work'] as $experience): ?>
                <?php displayWorkExperience($experience); ?>
            <?php endforeach; ?>
        </section>

        <p><a href="index.php">← Back to Team</a></p>
    </div>
</body>
</html>