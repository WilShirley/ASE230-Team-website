<?php
$team = [
    [
        "name" => "Wil Shirley",
        "title" => "Geek Squad Consultation Agent",
        "email" => "shirleyw1@mymail.nku.edu",
        "phone" => "859 954 2598",
        "location" => "Cynthiana, KY",
        "linkedin" => "https://www.linkedin.com/in/wil-shirley-10487334b",
        "github" => "https://github.com/WilShirley",
        "website" => "nku.edu",
        "dob" => "2004-05-20",
        "image" => "wil.jpg",
        "summary" => "I'm an agent who assists people with their day to day tech problems.",
        "work" => [
            [
                "role" => "Consultation Agent",
                "company" => "Geek Squad",
                "dates" => "2025 – Present",
                "desc" => "Assist people with tech problems; perform functionality checks; guarantee smooth repairs."
            ],
            [
                "role" => "Information Systems Assistant",
                "company" => "Harrison Memorial Hospital",
                "dates" => "2023 – 2025",
                "desc" => "Performed help desk as well as pulling wire."
            ]
        ]
    ],
    [
        "name" => "JR Mcfarland",
        "title" => "Crew Member",
        "email" => "none",
        "phone" => "none",
        "location" => "Kentucky",
        "linkedin" => "",
        "github" => "",
        "website" => "",
        "dob" => "2003-11-15",
        "image" => "jr.jpg",
        "summary" => "Recent high school graduate with customer service experience.",
        "work" => [
            [
                "role" => "Crew Member",
                "company" => "McDonalds",
                "dates" => "2020 – 2023",
                "desc" => "Took orders, handled customer service, and kept work areas clean."
            ],
            [
                "role" => "Stock Clerk",
                "company" => "Walmart",
                "dates" => "2023 – 2025",
                "desc" => "Unloaded trucks, stocked shelves, and assisted customers."
            ]
        ]
    ],
    [
        "name" => "Logan Hein",
        "title" => "Retail Associate",
        "email" => "none",
        "phone" => "none",
        "location" => "Kentucky",
        "linkedin" => "",
        "github" => "",
        "website" => "",
        "dob" => "2004-02-02",
        "image" => "logan.jpg",
        "summary" => "Motivated worker with a background in retail and teamwork.",
        "work" => [
            [
                "role" => "Retail Associate",
                "company" => "Kroger",
                "dates" => "2021 – 2024",
                "desc" => "Assisted customers, stocked products, and handled checkout."
            ],
            [
                "role" => "Warehouse Helper",
                "company" => "UPS",
                "dates" => "2024 – 2025",
                "desc" => "Loaded/unloaded packages and maintained efficiency in shipping."
            ]
        ]
    ]
];

function e($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function calculateAge($dob) {
    $dobDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($dobDate)->y;
}

function displayMemberCard($member, $index) {
    ?>
    <div class="col-md-4">
        <div class="card mb-4">
            <img src="assets/images/<?= e($member['image']) ?>" class="card-img-top" alt="<?= e($member['name']) ?>">
            <div class="card-body">
                <h5 class="card-title"><?= e($member['name']) ?></h5>
                <p class="card-text"><?= e($member['title']) ?></p>
                <p>Age: <?= calculateAge($member['dob']) ?></p>
                <p><i class="fas fa-map-marker-alt"></i> <?= e($member['location']) ?></p>
                <a href="detail.php?id=<?= $index ?>" class="btn btn-primary">View profile</a>
            </div>
        </div>
    </div>
    <?php
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Our Team</title>
    <meta charset="utf-8">
    <link href="assets/css/pillar-1.css" rel="stylesheet">
    <script defer src="assets/fontawesome/js/all.min.js"></script>
</head>
<body>
    <div class="container">
        <header class="my-4">
            <h1>Our Team</h1>
            <p>Click a member to view details</p>
        </header>
        <div class="row">
            <?php foreach ($team as $index => $member): ?>
                <?php displayMemberCard($member, $index); ?>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>